<?php

namespace Ryan77mln\Discord;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;

class Main extends PluginBase {
    public Config $config;

    protected function onEnable(): void
    {
        $this->config = new Config($this->getDataFolder()."config.yml", Config::YAML, array("discord" => "https://discord.gg/azurmc"));
    }

    protected function onLoad(): void
    {
        $this->config = new Config($this->getDataFolder()."config.yml", Config::YAML, array("discord" => "https://discord.gg/azurmc"));
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool
    {
        if($command->getName() === "discord"){
            $sender->sendMessage($this->config->get("discord"));
        }
        return true;
    }
}